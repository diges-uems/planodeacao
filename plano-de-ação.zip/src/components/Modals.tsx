import React from 'react';
import type { Fragility } from '../types';
import { X, Check } from 'lucide-react';

export interface AlertModalProps {
    isOpen: boolean;
    onClose: () => void;
    title: string;
    message: string;
}

export function AlertModal({ isOpen, onClose, title, message }: AlertModalProps) {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white rounded-[2rem] w-full max-w-sm p-8 text-center bento-shadow animate-in">
                <h3 className="text-xl font-black mb-2 text-uems-blue">{title}</h3>
                <p className="text-sm text-slate-500 mb-8 font-medium">{message}</p>
                <button onClick={onClose} className="w-full py-3 bg-slate-900 text-white font-bold rounded-xl text-sm uppercase">Entendi</button>
            </div>
        </div>
    );
}

export interface ConfirmModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => void;
    title: string;
    message: string;
    confirmText: string;
    isProcessing?: boolean;
}

export function ConfirmModal({ isOpen, onClose, onConfirm, title, message, confirmText, isProcessing }: ConfirmModalProps) {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[60] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white rounded-[2rem] w-full max-w-sm p-8 text-center border-t-8 border-red-500 animate-in">
                <h3 className="text-2xl font-black mb-4">{title}</h3>
                <p className="text-sm text-slate-500 mb-8 font-medium">{message}</p>
                <div className="flex gap-3">
                    <button onClick={onClose} disabled={isProcessing} className="flex-1 py-3 bg-slate-50 text-slate-500 font-bold rounded-xl text-sm border disabled:opacity-50">Cancelar</button>
                    <button onClick={onConfirm} disabled={isProcessing} className="flex-1 py-3 bg-red-600 text-white font-bold rounded-xl text-sm shadow-lg disabled:opacity-50">
                        {isProcessing ? "Processando..." : confirmText}
                    </button>
                </div>
            </div>
        </div>
    );
}

interface CartModalProps {
    isOpen: boolean;
    onClose: () => void;
    cart: Fragility[];
    onRemove: (idx: number) => void;
    onSubmit: () => void;
    isSubmitting: boolean;
}

export function CartModal({ isOpen, onClose, cart, onRemove, onSubmit, isSubmitting }: CartModalProps) {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white rounded-[2rem] w-full max-w-2xl max-h-[85vh] flex flex-col bento-shadow overflow-hidden animate-in">
                <div className="p-6 border-b flex justify-between items-center bg-slate-50">
                    <h3 className="text-xl font-black text-uems-blue uppercase tracking-tight">Itens para Enviar</h3>
                    <button onClick={onClose} className="text-[10px] font-black text-slate-400 border border-slate-200 px-3 py-1 rounded-full uppercase bg-white">Fechar</button>
                </div>
                
                <div className="p-6 overflow-y-auto space-y-3 flex-1 bg-white">
                    {cart.map((item, idx) => (
                        <div key={idx} className="p-4 border rounded-xl bg-slate-50 flex justify-between items-center text-xs">
                            <span><strong>[{item.ano}]</strong> {item.curso} - {item.fragilidade.substring(0, 30)}...</span>
                            <button onClick={() => onRemove(idx)} className="text-red-500 font-bold">Remover</button>
                        </div>
                    ))}
                    {cart.length === 0 && (
                        <p className="text-center text-slate-400 italic">O carrinho está vazio.</p>
                    )}
                </div>

                <div className="p-6 border-t bg-slate-50">
                    <button 
                        onClick={onSubmit} 
                        disabled={cart.length === 0 || isSubmitting}
                        className="w-full py-4 bg-emerald-600 disabled:opacity-50 text-white font-black rounded-2xl shadow-lg transition-all"
                    >
                        {isSubmitting ? "Sincronizando..." : "Confirmar Envio Final"}
                    </button>
                </div>
            </div>
        </div>
    );
}

interface SuccessModalProps {
    isOpen: boolean;
    onClose: () => void;
    message: string;
}

export function SuccessModal({ isOpen, onClose, message }: SuccessModalProps) {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white rounded-[2rem] w-full max-w-sm p-8 text-center border-t-8 border-emerald-500 animate-in">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 font-black">
                    <Check className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-black mb-2 text-slate-900">Sucesso!</h3>
                <p className="text-sm text-slate-500 mb-8 font-medium">{message}</p>
                <button onClick={onClose} className="w-full py-3 bg-emerald-600 text-white font-bold rounded-xl shadow-lg uppercase text-xs">
                    Fechar e Voltar
                </button>
            </div>
        </div>
    );
}
