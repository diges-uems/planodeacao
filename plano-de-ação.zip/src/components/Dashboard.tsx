import React, { useEffect, useState, useMemo } from 'react';
import { fetchDashboardData, deleteFragility, updateFragility } from '../lib/api';
import { generatePdfHtml, sanitizeSearch } from '../lib/utils';
import { DIMENSIONS, COURSES } from '../lib/constants';
import type { Fragility, User } from '../types';
import { FileDown, RefreshCw, Plus, LogOut, Edit2, Trash2, Search } from 'lucide-react';
import { ConfirmModal } from './Modals';
import { EditModal } from './EditModal';

interface DashboardProps {
    user: User;
    onNewRecord?: () => void;
    onLogout: () => void;
    onEdit?: (fragility: Fragility) => void;
}

export function Dashboard({ user, onNewRecord, onLogout, onEdit }: DashboardProps) {
    const isProe = user.role === 'reitoria';
    const [data, setData] = useState<Fragility[]>([]);
    const [loading, setLoading] = useState(true);
    const [itemToDelete, setItemToDelete] = useState<Fragility | null>(null);
    const [isDeleting, setIsDeleting] = useState(false);
    const [itemToEdit, setItemToEdit] = useState<Fragility | null>(null);
    const [isEditing, setIsEditing] = useState(false);
    
    // Filters
    const [filterAnos, setFilterAnos] = useState<string[]>([]);
    const [selectedAno, setSelectedAno] = useState('');
    const [selectedDimensao, setSelectedDimensao] = useState('');
    const [searchCourse, setSearchCourse] = useState('');
    const [showAutocomplete, setShowAutocomplete] = useState(false);
    
    // Pagination
    const [currentPage, setCurrentPage] = useState(1);
    const ITEMS_PER_PAGE = 25;

    // Selection for PDF
    const [selectedForPdf, setSelectedForPdf] = useState<Set<string>>(new Set());

    const loadData = async () => {
        setLoading(true);
        const result = await fetchDashboardData();
        if (result) {
            setData(result);
            const years = Array.from(new Set(result.map(i => i.ano))).sort((a, b) => Number(b) - Number(a));
            setFilterAnos(years);
        } else {
            alert('Falha ao carregar dados. Verifique sua conexão.');
        }
        setLoading(false);
    };

    useEffect(() => {
        loadData();
    }, []);

    // Filter pipeline
    const filteredData = useMemo(() => {
        let filtered = data.filter(d => 
            !(d.fragilidade || '').toString().toUpperCase().includes("EXCLUIR") && 
            !(d.fragilidade || '').toString().toUpperCase().includes("EXCLUÍDO")
        );

        if (!isProe) {
            filtered = filtered.filter(d => d.curso === user.courseName);
        } else {
            if (searchCourse) {
                const searchTerms = searchCourse.toLowerCase().split(' ');
                filtered = filtered.filter(d => {
                    const searchSpace = sanitizeSearch(`${d.codigoCurso || ''} ${d.curso || ''}`);
                    return searchTerms.every(term => searchSpace.includes(term));
                });
            }
            if (selectedDimensao) {
                filtered = filtered.filter(d => d.tipo === selectedDimensao);
            }
        }

        if (selectedAno) {
            filtered = filtered.filter(d => d.ano === selectedAno);
        }

        return filtered;
    }, [data, user, isProe, searchCourse, selectedDimensao, selectedAno]);

    const paginatedData = filteredData.slice(0, currentPage * ITEMS_PER_PAGE);

    const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.checked) {
            const allIds = new Set(filteredData.map(i => `${i.ano}|${i.curso}|${i.fragilidade}`));
            setSelectedForPdf(allIds);
        } else {
            setSelectedForPdf(new Set());
        }
    };

    const handleToggleSelect = (uid: string) => {
        const next = new Set(selectedForPdf);
        if (next.has(uid)) next.delete(uid);
        else next.add(uid);
        setSelectedForPdf(next);
    };

    const confirmDelete = async () => {
        if (!itemToDelete) return;
        setIsDeleting(true);
        setData(prev => prev.filter(d => !(d.ano === itemToDelete.ano && d.curso === itemToDelete.curso && d.fragilidade === itemToDelete.fragilidade)));
        await deleteFragility(itemToDelete.ano, itemToDelete.curso, itemToDelete.fragilidade);
        setIsDeleting(false);
        setItemToDelete(null);
    };

    const handleSaveEdit = async (newData: Partial<Fragility>) => {
        if (!itemToEdit) return;
        setIsEditing(true);
        const success = await updateFragility(itemToEdit.ano, itemToEdit.curso, itemToEdit.fragilidade, newData);
        if (success) {
            setData(prev => prev.map(d => 
                (d.ano === itemToEdit.ano && d.curso === itemToEdit.curso && d.fragilidade === itemToEdit.fragilidade)
                    ? { ...d, ...newData } as Fragility : d
            ));
        } else {
            alert("Falha ao salvar edição.");
        }
        setIsEditing(false);
        setItemToEdit(null);
    };

    const handleExportPdf = () => {
        if (selectedForPdf.size === 0) {
            alert("Por favor, selecione (marque a caixinha) pelo menos uma fragilidade na tabela para gerar o relatório.");
            return;
        }

        const dataToExport = filteredData.filter(i => selectedForPdf.has(`${i.ano}|${i.curso}|${i.fragilidade}`));
        const escopo = isProe ? (searchCourse ? `Filtro: ${searchCourse}` : 'Todos os Cursos / Visão Geral') : user.courseName!;
        
        const html = generatePdfHtml(isProe, escopo, selectedAno || 'Todos', dataToExport);
        
        const printWindow = window.open('', '_blank');
        if (printWindow) {
            printWindow.document.open();
            printWindow.document.write(html);
            printWindow.document.close();
            setSelectedForPdf(new Set());
        } else {
            alert("O seu navegador bloqueou a abertura da aba de impressão (Pop-up).");
        }
    };

    // Autocomplete Logic
    const autocompleteResults = useMemo(() => {
        if (!searchCourse) return [];
        const query = sanitizeSearch(searchCourse);
        if (!query) return [];
        const searchTerms = query.split(' ');
        return Object.values(COURSES).filter(v => {
            const searchSpace = sanitizeSearch(v.replace('||', ' '));
            return searchTerms.every(term => searchSpace.includes(term));
        }).sort((a,b) => a.localeCompare(b));
    }, [searchCourse]);

    return (
        <>
            <div className="space-y-6 animate-in w-full text-left">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-4xl font-black tracking-tighter text-slate-900">{isProe ? 'Painel PROE' : 'Gestão do Curso'}</h1>
                    <p className="text-uems-blue font-bold text-sm"></p>
                </div>
                
                <div className="w-full md:w-auto flex flex-col sm:flex-row gap-2 sm:gap-3">
                    <div className="flex-1 sm:flex-none sm:w-40 relative">
                        <select 
                            value={selectedAno} 
                            onChange={e => { setSelectedAno(e.target.value); setCurrentPage(1); }} 
                            className="input-uems py-3 w-full shadow-sm text-sm font-bold border-uems-blue/20"
                        >
                            <option value="">Todos os Anos</option>
                            {filterAnos.map(y => <option key={y} value={y}>{y}</option>)}
                        </select>
                    </div>
                    
                    {isProe && (
                        <>
                            <div className="flex-1 sm:flex-none sm:w-60 relative">
                                <select 
                                    value={selectedDimensao} 
                                    onChange={e => { setSelectedDimensao(e.target.value); setCurrentPage(1); }} 
                                    className="input-uems py-3 w-full shadow-sm text-sm font-bold border-uems-blue/20"
                                >
                                    <option value="">Todas as Dimensões</option>
                                    {DIMENSIONS.map(d => <option key={d} value={d}>{d}</option>)}
                                </select>
                            </div>

                            <div className="flex-[2] sm:flex-none sm:w-80 relative">
                                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-slate-400">
                                    <Search className="w-4 h-4" />
                                </div>
                                <input 
                                    type="text" 
                                    value={searchCourse}
                                    onChange={e => { setSearchCourse(e.target.value); setShowAutocomplete(true); setCurrentPage(1); }}
                                    onFocus={() => setShowAutocomplete(true)}
                                    onBlur={() => setTimeout(() => setShowAutocomplete(false), 200)}
                                    placeholder="Filtrar por nome ou código..." 
                                    className="input-uems pl-10 py-3 w-full shadow-sm text-sm font-bold"
                                />
                                {showAutocomplete && searchCourse && (
                                    <ul className="absolute z-50 w-full mt-2 bg-white border border-slate-200 rounded-xl shadow-2xl max-h-60 overflow-y-auto divide-y divide-slate-50">
                                        {autocompleteResults.length > 0 ? (
                                            autocompleteResults.map(v => {
                                                const [c, n] = v.split('||');
                                                return (
                                                    <li key={v} className="px-4 py-3 hover:bg-blue-50 hover:text-uems-blue cursor-pointer text-xs font-bold transition-colors"
                                                        onClick={() => { setSearchCourse(`${c} - ${n}`); setShowAutocomplete(false); setCurrentPage(1); }}>
                                                        {c} - {n}
                                                    </li>
                                                );
                                            })
                                        ) : (
                                            <li className="px-4 py-3 text-xs text-slate-400 italic">Nenhum curso encontrado</li>
                                        )}
                                    </ul>
                                )}
                            </div>
                        </>
                    )}
                </div>

                <div className="flex flex-wrap gap-2 w-full md:w-auto">
                    <button onClick={handleExportPdf} className="flex-1 md:flex-none px-5 py-3 bg-slate-800 text-white rounded-xl font-bold text-sm shadow-md hover:bg-slate-900 transition-all flex items-center justify-center gap-2">
                        <FileDown className="w-4 h-4" /> <span>Exportar PDF</span>
                    </button>
                    <button onClick={loadData} className="flex-1 md:flex-none px-6 py-3 bg-uems-blue text-white rounded-xl font-bold text-sm shadow-md hover:bg-uems-dark transition-all flex items-center justify-center gap-2">
                        <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> Atualizar
                    </button>
                    {!isProe && onNewRecord && (
                        <button onClick={onNewRecord} className="flex-1 md:flex-none px-5 py-3 bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-xl font-bold text-sm hover:bg-emerald-200 transition-all flex items-center justify-center gap-2">
                            <Plus className="w-4 h-4" /> Novo Registro
                        </button>
                    )}
                    <button onClick={onLogout} className="flex-1 md:flex-none px-5 py-3 bg-slate-200 text-slate-700 rounded-xl font-bold text-sm hover:bg-slate-300 transition-all border border-slate-300 flex items-center justify-center gap-2">
                        <LogOut className="w-4 h-4" /> Sair
                    </button>
                </div>
            </div>

            <div className="bg-white rounded-[2rem] bento-shadow border border-slate-100 overflow-hidden">
                <div className="overflow-x-auto no-scrollbar">
                    <table className="fixed-table text-left w-full min-w-[1000px]">
                        <thead className="text-[10px] uppercase font-black text-slate-400 bg-slate-50">
                            <tr>
                                <th className="p-4 w-10 text-center">
                                    <input type="checkbox" className="w-4 h-4 cursor-pointer accent-uems-blue" onChange={handleSelectAll} checked={filteredData.length > 0 && selectedForPdf.size === filteredData.length} />
                                </th>
                                {isProe && <th className="p-4">Curso</th>}
                                <th className="p-4">Ano</th>
                                <th className="p-4">Dimensão</th>
                                <th className="p-4">Ação</th>
                                <th className="p-4">Fonte</th>
                                <th className="p-4">Prazo</th>
                                <th className="p-4">Recursos</th>
                                <th className="p-4">Reunião / Minuta</th>
                                {!isProe && <th className="p-4 text-center">Ações</th>}
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50">
                            {loading ? (
                                <tr>
                                    <td colSpan={10} className="p-20 text-center animate-pulse font-bold text-slate-400 uppercase tracking-widest text-[10px]">
                                        Sincronizando dados...
                                    </td>
                                </tr>
                            ) : paginatedData.length === 0 ? (
                                <tr>
                                    <td colSpan={10} className="p-10 text-center text-slate-400 italic font-medium">
                                        Nenhum registro encontrado.
                                    </td>
                                </tr>
                            ) : (
                                paginatedData.map((row, idx) => {
                                    const uid = `${row.ano}|${row.curso}|${row.fragilidade}`;
                                    const isChecked = selectedForPdf.has(uid);
                                    
                                    return (
                                        <tr key={idx} className="text-[11px] border-b border-slate-50 hover:bg-slate-50">
                                            <td className="p-4 text-center">
                                                <input type="checkbox" className="w-4 h-4 cursor-pointer accent-uems-blue" checked={isChecked} onChange={() => handleToggleSelect(uid)} />
                                            </td>
                                            {isProe && <td className="p-4 font-bold text-uems-blue">{row.curso}</td>}
                                            <td className="p-4 font-black text-slate-400">{row.ano}</td>
                                            <td className="p-4"><strong>{row.tipo}</strong><br/>{row.fragilidade}</td>
                                            <td className="p-4 text-slate-600 font-medium">{row.acao}</td>
                                            <td className="p-4"><strong>{row.fonte}</strong><br/>Nota: {row.conceito}</td>
                                            <td className="p-4">{row.prazo}<br/><strong>{row.responsavel}</strong></td>
                                            <td className="p-4 text-slate-500 italic">{row.recursos}</td>
                                            <td className="p-4">
                                                <strong>{row.dataReuniao || '-'}</strong><br/>
                                                <span className="text-blue-500 break-all text-[10px]">{row.minutaReuniao || ''}</span>
                                            </td>
                                            {!isProe && (
                                                <td className="p-4 text-center">
                                                    <div className="flex gap-1 justify-center">
                                                        <button onClick={() => setItemToEdit(row)} className="bg-blue-50 text-blue-600 px-2 py-1 rounded-lg font-black uppercase text-[9px]">Editar</button>
                                                        <button onClick={() => setItemToDelete(row)} className="bg-red-50 text-red-600 px-2 py-1 rounded-lg font-black text-[9px]">X</button>
                                                    </div>
                                                </td>
                                            )}
                                        </tr>
                                    );
                                })
                            )}
                        </tbody>
                    </table>
                </div>

                {filteredData.length > currentPage * ITEMS_PER_PAGE && (
                    <div className="p-6 bg-slate-50 border-t border-slate-100 flex flex-col items-center justify-center gap-3">
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                            Mostrando {paginatedData.length} de {filteredData.length} registros
                        </span>
                        <button onClick={() => setCurrentPage(prev => prev + 1)} className="px-6 py-2.5 bg-white border border-slate-200 text-slate-600 font-bold rounded-xl text-xs hover:bg-slate-100 transition-all shadow-sm">
                            Carregar mais registros...
                        </button>
                    </div>
                )}
            </div>
        </div>

        <ConfirmModal
                isOpen={!!itemToDelete}
                onClose={() => setItemToDelete(null)}
                onConfirm={confirmDelete}
                title="Confirmar?"
                message="O registro será removido do painel."
                confirmText="Sim, Excluir"
                isProcessing={isDeleting}
            />

            <EditModal
                isOpen={!!itemToEdit}
                onClose={() => setItemToEdit(null)}
                item={itemToEdit}
                onSave={handleSaveEdit}
                isProcessing={isEditing}
            />
        </>
    );
}
