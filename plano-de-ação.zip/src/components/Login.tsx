import React, { useState, useRef, useEffect } from 'react';
import { LogIn, Eye, EyeOff, XCircle } from 'lucide-react';
import { COURSES } from '../lib/constants';
import type { User } from '../types';

interface LoginProps {
    onLogin: (user: User) => void;
}

export function Login({ onLogin }: LoginProps) {
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [error, setError] = useState(false);
    const passwordRef = useRef<HTMLInputElement>(null);

    const handleLogin = (e?: React.FormEvent) => {
        if (e) e.preventDefault();
        
        const pwd = password.trim().toLowerCase();
        if (!pwd) {
            setError(true);
            return;
        }

        const master = [117,101,109,115,50,48,50,54].map(c => String.fromCharCode(c)).join('');
        if (pwd === master) {
            onLogin({ role: 'reitoria' });
            return;
        }

        const hash = btoa(pwd);
        if (COURSES[hash]) {
            const [courseId, courseName] = COURSES[hash].split('||');
            onLogin({ role: 'coordenador', courseId, courseName });
        } else {
            setError(true);
        }
    };

    return (
        <div className="flex items-center justify-center animate-in w-full min-h-screen bg-uems-dark relative overflow-hidden">
            <img 
                src="https://www.uems.br/anexos/imagens/conteudo/uems_imagens_2023-09-22_13-02-19.png" 
                className="absolute inset-0 w-full h-full object-cover opacity-70" 
                alt="Fundo UEMS" 
            />
            <div className="absolute inset-0 bg-gradient-to-r from-uems-dark/95 via-uems-blue/90 to-uems-blue/40"></div>
            
            <div className="absolute top-8 left-8 md:top-12 md:left-12 z-20 flex items-center gap-2">
                <span className="bg-white/20 backdrop-blur-md border border-white/30 text-white px-5 py-2 rounded-full text-xs md:text-sm font-black tracking-widest shadow-lg">
                    UEMS • PROE
                </span>
            </div>

            <div className="relative z-10 flex flex-col md:flex-row items-center justify-between w-full max-w-7xl px-6 md:px-12 gap-12 text-left">
                <div className="text-white w-full max-w-2xl mb-8 md:mb-0">
                    <span className="text-emerald-300 font-extrabold tracking-widest uppercase text-xs md:text-sm mb-4 block drop-shadow-md">
                        Gestão Estratégica Institucional
                    </span>
                    <h1 className="text-5xl md:text-7xl font-black tracking-tighter mb-6 leading-tight drop-shadow-lg">
                        Plano de Ação<br/><span className="text-blue-100">dos Cursos</span>
                    </h1>
                    <p className="text-lg md:text-2xl text-slate-200 font-medium opacity-95 leading-relaxed max-w-lg drop-shadow">
                        Matriz de mitigação de fragilidades organizada por curso, unidade acadêmica e código.
                    </p>
                </div>

                <div className="bg-white/10 backdrop-blur-2xl border border-white/20 p-8 md:p-12 rounded-[2.5rem] shadow-2xl w-full max-w-md hover:shadow-[0_0_60px_rgba(0,51,140,0.4)] transition-shadow duration-500">
                    <h3 className="text-white text-2xl font-black tracking-tight mb-8 text-center">Acesso ao Sistema</h3>
                    
                    <form onSubmit={handleLogin} className="space-y-6">
                        <div className="relative group">
                            <input 
                                ref={passwordRef}
                                type={showPassword ? "text" : "password"} 
                                value={password}
                                onChange={(e) => {
                                    setPassword(e.target.value);
                                    setError(false);
                                }}
                                className="w-full bg-white border-2 border-transparent focus:border-emerald-400 focus:ring-4 focus:ring-emerald-400/20 rounded-xl px-4 py-5 text-center text-xl tracking-widest font-black text-slate-800 placeholder-slate-400 shadow-inner outline-none transition-all pr-12" 
                                placeholder="Senha..." 
                            />
                            <button 
                                type="button" 
                                onClick={() => setShowPassword(!showPassword)} 
                                className="absolute inset-y-0 right-0 flex items-center pr-5 text-slate-400 hover:text-emerald-500 transition-colors focus:outline-none" 
                                title="Mostrar Senha"
                            >
                                {showPassword ? <EyeOff className="w-6 h-6" /> : <Eye className="w-6 h-6" />}
                            </button>
                        </div>
                        
                        {error && (
                            <div className="animate-shake">
                                <p className="text-red-300 text-xs font-bold text-center bg-red-900/40 py-3 px-3 rounded-lg border border-red-500/30 backdrop-blur-sm flex items-center justify-center gap-2">
                                    <XCircle className="w-4 h-4 shrink-0" />
                                    <span>Senha incorreta.</span>
                                </p>
                            </div>
                        )}

                        <button 
                            type="submit" 
                            className="w-full py-5 bg-emerald-500 hover:bg-emerald-400 text-white font-black text-lg rounded-xl transition-all shadow-[0_0_20px_rgba(16,185,129,0.3)] hover:shadow-[0_0_30px_rgba(16,185,129,0.6)] hover:-translate-y-1 flex justify-center items-center gap-2 group"
                        >
                            <span>Entrar no Portal</span>
                            <LogIn className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
}
