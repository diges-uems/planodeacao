import React, { useState, useEffect } from 'react';
import type { Fragility } from '../types';
import { DIMENSIONS, SOURCES } from '../lib/constants';

interface EditModalProps {
    isOpen: boolean;
    onClose: () => void;
    item: Fragility | null;
    onSave: (newData: Partial<Fragility>) => Promise<void>;
    isProcessing: boolean;
}

export function EditModal({ isOpen, onClose, item, onSave, isProcessing }: EditModalProps) {
    const [formData, setFormData] = useState<Partial<Fragility>>({});

    useEffect(() => {
        if (item) {
            setFormData({
                tipo: item.tipo,
                fragilidade: item.fragilidade,
                fonte: item.fonte,
                conceito: item.conceito,
                acao: item.acao,
                prazo: item.prazo,
                responsavel: item.responsavel,
                recursos: item.recursos,
                dataReuniao: item.dataReuniao || '',
                minutaReuniao: item.minutaReuniao || ''
            });
        }
    }, [item]);

    if (!isOpen || !item) return null;

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        await onSave(formData);
    };

    return (
        <div className="fixed inset-0 z-[70] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white rounded-[2rem] w-full max-w-2xl max-h-[90vh] overflow-y-auto bento-shadow p-8 no-scrollbar relative animate-in text-left">
                <h3 className="text-2xl font-black tracking-tight mb-6 text-uems-blue border-b pb-4">Editar Registro</h3>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label>3. Dimensão</label>
                            <select name="tipo" value={formData.tipo} onChange={handleChange} className="input-uems font-bold" required>
                                <option value="">Selecione...</option>
                                {DIMENSIONS.map(dim => <option key={dim} value={dim}>{dim}</option>)}
                            </select>
                        </div>
                        <div>
                            <label>5. Fonte</label>
                            <select name="fonte" value={formData.fonte} onChange={handleChange} className="input-uems font-bold" required>
                                <option value="">Selecione...</option>
                                {SOURCES.map(source => <option key={source} value={source}>{source}</option>)}
                            </select>
                        </div>
                    </div>
                    <div>
                        <label>4. Descrição</label>
                        <textarea name="fragilidade" value={formData.fragilidade} onChange={handleChange} rows={2} className="input-uems font-medium" required></textarea>
                    </div>
                    <div>
                        <label>7. Ação</label>
                        <textarea name="acao" value={formData.acao} onChange={handleChange} rows={2} className="input-uems font-medium" required></textarea>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label>6. Conceito</label>
                            <input type="text" name="conceito" value={formData.conceito} onChange={handleChange} className="input-uems font-black" required />
                        </div>
                        <div>
                            <label>8. Prazo</label>
                            <input type="text" name="prazo" value={formData.prazo} onChange={handleChange} className="input-uems font-bold" required />
                        </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label>9. Responsável</label>
                            <input type="text" name="responsavel" value={formData.responsavel} onChange={handleChange} className="input-uems font-bold" required />
                        </div>
                        <div>
                            <label>10. Recursos</label>
                            <input type="text" name="recursos" value={formData.recursos} onChange={handleChange} className="input-uems font-bold" required />
                        </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label>11. Data de Reunião</label>
                            <input type="text" name="dataReuniao" value={formData.dataReuniao} onChange={handleChange} className="input-uems font-bold" required />
                        </div>
                        <div>
                            <label>12. Minuta</label>
                            <input type="text" name="minutaReuniao" value={formData.minutaReuniao} onChange={handleChange} className="input-uems font-bold" required />
                        </div>
                    </div>
                    <div className="flex gap-3 pt-4 border-t mt-6">
                        <button type="button" onClick={onClose} disabled={isProcessing} className="flex-1 py-3 bg-slate-100 font-bold rounded-xl border disabled:opacity-50">Cancelar</button>
                        <button type="submit" disabled={isProcessing} className="flex-1 py-3 bg-uems-blue text-white font-bold rounded-xl shadow-lg disabled:opacity-50">
                            {isProcessing ? 'Salvando...' : 'Salvar Edição'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
