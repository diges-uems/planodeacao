import React, { useState, useRef } from 'react';
import type { Fragility, User } from '../types';
import { DIMENSIONS, SOURCES } from '../lib/constants';

interface ActionFormProps {
    user: User;
    cartLength: number;
    onSaveToCart: (fragility: Fragility) => void;
    onReview: () => void;
    showAlert: (title: string, message: string) => void;
}

const MAGIC_DADOS: Record<string, Partial<Fragility>> = {
    "Infraestrutura": {
        fragilidade: "Falta de referências bibliográficas",
        fonte: "Relatório Enade (INEP)",
        conceito: "1",
        acao: "Renovação do acervo bibliográfico",
        prazo: "1 ano",
        responsavel: "Comissão de desenvolvimento de coleções da UEMS, Comitê Enade e CDE",
        recursos: "Reuniões, Livros novos",
        dataReuniao: "25/05/2026",
        minutaReuniao: "Ata nº 05/2026 - Aprovada (Drive)"
    },
    "Organização Didático-Pedagógica": {
        fragilidade: "Estrutura curricular pouco flexível",
        fonte: "Avaliação in loco (CEE/MS)",
        conceito: "1",
        acao: "Reformulação do PPC e implementação de um sistema por créditos",
        prazo: "2 anos",
        responsavel: "CDE e Colegiado",
        recursos: "Reuniões da comissão e pedagógicas",
        dataReuniao: "10/06/2026",
        minutaReuniao: "Link SEI nº 12345/2026"
    },
    "Corpo Docente e Tutorial": {
        fragilidade: "Lacunas formativas iniciais",
        fonte: "Relatório de Autoavaliação",
        conceito: "-",
        acao: "Implementar programa de nivelamento e monitoria acadêmica (1º e 2º ano) com formalização no PPC",
        prazo: "6 meses",
        responsavel: "CDE e Colegiado",
        recursos: "Bolsas de monitoria, moodle e horas docentes",
        dataReuniao: "A agendar",
        minutaReuniao: "Pendente"
    }
};

export function ActionForm({ user, cartLength, onSaveToCart, onReview, showAlert }: ActionFormProps) {
    const currentYear = new Date().getFullYear();
    const years = Array.from({ length: 6 }, (_, i) => currentYear - 1 + i);

    const [formData, setFormData] = useState<Partial<Fragility>>({
        ano: currentYear.toString(),
        codigoCurso: user.courseId || '',
        curso: user.courseName || '',
        tipo: '',
        fragilidade: '',
        fonte: '',
        conceito: '',
        acao: '',
        prazo: '',
        responsavel: '',
        recursos: '',
        dataReuniao: '',
        minutaReuniao: ''
    });

    // Magic Typing State
    const [typedFields, setTypedFields] = useState<Set<string>>(new Set());
    const isTypingRef = useRef(false);

    const handleMagicFocus = (field: keyof Fragility, isSelect: boolean = false) => {
        if (user.courseName !== 'Teste' || !formData.tipo) return;
        const magicData = MAGIC_DADOS[formData.tipo];
        if (!magicData) return;

        if (isTypingRef.current || typedFields.has(field as string)) return;

        const textToType = magicData[field] || '';
        if (!textToType) return;

        isTypingRef.current = true;
        
        if (isSelect) {
            setFormData(prev => ({ ...prev, [field]: textToType }));
            setTypedFields(prev => new Set(prev).add(field as string));
            isTypingRef.current = false;
        } else {
            let charIndex = 0;
            setFormData(prev => ({ ...prev, [field]: '' }));
            
            const typeChar = () => {
                if (charIndex < textToType.length) {
                    const char = textToType.charAt(charIndex);
                    setFormData(prev => ({ ...prev, [field]: prev[field] + char }));
                    charIndex++;
                    setTimeout(typeChar, Math.random() * 30 + 10);
                } else {
                    setTypedFields(prev => new Set(prev).add(field as string));
                    isTypingRef.current = false;
                }
            };
            typeChar();
        }
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleRadioChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newTipo = e.target.value;
        
        if (user.courseName === 'Teste') {
            setFormData(prev => ({
                ...prev,
                tipo: newTipo,
                fragilidade: '', fonte: '', conceito: '', acao: '', 
                prazo: '', responsavel: '', recursos: '', dataReuniao: '', minutaReuniao: '' 
            }));
            setTypedFields(new Set());
        } else {
            setFormData(prev => ({ 
                ...prev, 
                tipo: newTipo
            }));
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        
        if (!formData.fragilidade?.trim() || !formData.conceito?.trim()) {
            showAlert("Atenção", "Preencha os campos obrigatórios.");
            return;
        }

        onSaveToCart({
            ano: formData.ano!,
            codigoCurso: formData.codigoCurso!,
            curso: formData.curso!,
            tipo: formData.tipo || "N/A",
            fragilidade: formData.fragilidade.trim(),
            fonte: formData.fonte!,
            conceito: formData.conceito.trim(),
            acao: formData.acao!.trim(),
            prazo: formData.prazo!.trim(),
            responsavel: formData.responsavel!.trim(),
            recursos: formData.recursos!.trim(),
            dataReuniao: formData.dataReuniao!.trim(),
            minutaReuniao: formData.minutaReuniao!.trim()
        });

        // Reset fields
        setFormData(prev => ({
            ...prev,
            tipo: '',
            fragilidade: '',
            fonte: '',
            conceito: '',
            acao: '',
            prazo: '',
            responsavel: '',
            recursos: '',
            dataReuniao: '',
            minutaReuniao: ''
        }));
        setTypedFields(new Set());
    };

    const handleReviewClick = () => {
        if (cartLength === 0) {
            showAlert("Atenção", "A sua lista está vazia. Adicione e salve pelo menos uma fragilidade.");
            return;
        }

        const hasPendingData = Boolean(
            formData.fragilidade?.trim() || formData.acao?.trim() || formData.conceito?.trim() ||
            formData.prazo?.trim() || formData.responsavel?.trim() || formData.recursos?.trim() ||
            formData.dataReuniao?.trim() || formData.minutaReuniao?.trim()
        );

        if (hasPendingData) {
            showAlert("Atenção", "Tem dados preenchidos no formulário. Clique em 'Salvar Fragilidade' primeiro ou limpe os campos.");
            return;
        }

        onReview();
    };

    return (
        <section className="bg-white rounded-[2rem] bento-shadow p-8 sm:p-10 border border-slate-100 animate-in">
            <form onSubmit={handleSubmit} className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 pb-6 border-b border-slate-50">
                    <div className="md:col-span-1">
                        <label>1. Ano de Referência</label>
                        <select name="ano" value={formData.ano} onChange={handleChange} className="input-uems font-bold" required>
                            {years.map(y => <option key={y} value={y}>{y}</option>)}
                        </select>
                    </div>
                    <div className="md:col-span-3">
                        <label>2. Curso / Unidade Acadêmica (Bloqueado)</label>
                        <input type="text" value={formData.curso} className="input-uems font-bold" readOnly tabIndex={-1} />
                    </div>
                </div>

                <fieldset>
                    <legend className="text-[11px] font-extrabold uppercase text-slate-500 mb-2 tracking-widest">3. Dimensão da Fragilidade</legend>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        {DIMENSIONS.map((dim) => (
                            <label key={dim} className="flex items-center gap-3 p-4 border rounded-xl cursor-pointer has-[:checked]:bg-blue-50 has-[:checked]:border-uems-blue transition-all mb-0 normal-case">
                                <input 
                                    type="radio" 
                                    name="tipo" 
                                    value={dim} 
                                    checked={formData.tipo === dim}
                                    onChange={handleRadioChange}
                                    className="w-4 h-4 text-uems-blue" 
                                    required 
                                />
                                <span className="text-xs font-bold text-slate-700 uppercase tracking-tight leading-tight">{dim}</span>
                            </label>
                        ))}
                    </div>
                </fieldset>

                <div>
                    <label>4. Descrição da Fragilidade</label>
                    <textarea 
                        name="fragilidade" 
                        value={formData.fragilidade} 
                        onChange={handleChange} 
                        onFocus={() => handleMagicFocus('fragilidade')}
                        rows={3} 
                        required 
                        className="input-uems" 
                        placeholder="Relate o problema (PPC, titulação, espaços, equipamentos...)"
                    />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label>5. Fonte Identificadora</label>
                        <select 
                            name="fonte" 
                            value={formData.fonte} 
                            onChange={handleChange} 
                            onFocus={() => handleMagicFocus('fonte', true)}
                            required 
                            className="input-uems font-semibold"
                        >
                            <option value="">Selecione...</option>
                            {SOURCES.map(source => <option key={source} value={source}>{source}</option>)}
                        </select>
                    </div>
                    <div>
                        <label>6. Conceito</label>
                        <input 
                            type="text" 
                            name="conceito" 
                            value={formData.conceito} 
                            onChange={handleChange} 
                            onFocus={() => handleMagicFocus('conceito')}
                            required 
                            className="input-uems text-center font-black" 
                            placeholder="Ex: 1 a 5 ou N/A" 
                        />
                    </div>
                </div>

                <div>
                    <label>7. Ação Prática Proposta</label>
                    <textarea 
                        name="acao" 
                        value={formData.acao} 
                        onChange={handleChange} 
                        onFocus={() => handleMagicFocus('acao')}
                        rows={3} 
                        required 
                        className="input-uems" 
                        placeholder="Quais medidas serão tomadas?"
                    />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label>8. Prazo</label>
                        <input 
                            type="text" 
                            name="prazo" 
                            value={formData.prazo} 
                            onChange={handleChange} 
                            onFocus={() => handleMagicFocus('prazo')}
                            required 
                            className="input-uems" 
                            placeholder="Ex: 6 meses" 
                        />
                    </div>
                    <div>
                        <label>9. Responsável</label>
                        <input 
                            type="text" 
                            name="responsavel" 
                            value={formData.responsavel} 
                            onChange={handleChange} 
                            onFocus={() => handleMagicFocus('responsavel')}
                            required 
                            className="input-uems" 
                            placeholder="Ex: Coordenador" 
                        />
                    </div>
                </div>

                <div>
                    <label>10. Recursos Necessários</label>
                    <textarea 
                        name="recursos" 
                        value={formData.recursos} 
                        onChange={handleChange} 
                        onFocus={() => handleMagicFocus('recursos')}
                        rows={2} 
                        required 
                        className="input-uems" 
                        placeholder="Financeiros, humanos..."
                    />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-2">
                    <div>
                        <label>11. Data de Reunião (CDE, Autoavaliação e Comitê ENADE)</label>
                        <input 
                            type="text" 
                            name="dataReuniao" 
                            value={formData.dataReuniao} 
                            onChange={handleChange} 
                            onFocus={() => handleMagicFocus('dataReuniao')}
                            required 
                            className="input-uems" 
                            placeholder="Ex: 15/04/2026, ou 'A agendar'" 
                        />
                    </div>
                    <div>
                        <label>12. Minuta da Reunião</label>
                        <input 
                            type="text" 
                            name="minutaReuniao" 
                            value={formData.minutaReuniao} 
                            onChange={handleChange} 
                            onFocus={() => handleMagicFocus('minutaReuniao')}
                            required 
                            className="input-uems" 
                            placeholder="Cole o link do Drive, SEI ou Ata..." 
                        />
                    </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 pt-6 border-t border-slate-50">
                    <button type="submit" className="flex-1 bg-uems-blue text-white font-bold py-4 rounded-2xl hover:bg-uems-dark shadow-xl transition-all">Salvar Fragilidade</button>
                    <button type="button" onClick={handleReviewClick} className="flex-1 bg-emerald-600 text-white font-black py-4 rounded-2xl hover:bg-emerald-700 shadow-xl transition-all">Revisar e Enviar</button>
                </div>
            </form>
        </section>
    );
}
