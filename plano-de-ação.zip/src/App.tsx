import React, { useState } from 'react';
import { Login } from './components/Login';
import { ActionForm } from './components/ActionForm';
import { Dashboard } from './components/Dashboard';
import { CartModal, SuccessModal, AlertModal } from './components/Modals';
import type { Fragility, User, ViewState } from './types';
import { submitCart } from './lib/api';
import { LogOut, LayoutDashboard } from 'lucide-react';

export default function App() {
    const [view, setView] = useState<ViewState>('login');
    const [user, setUser] = useState<User | null>(null);
    const [cart, setCart] = useState<Fragility[]>([]);
    
    // Modal states
    const [isCartOpen, setIsCartOpen] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [successMessage, setSuccessMessage] = useState('');
    const [alertState, setAlertState] = useState<{title: string, message: string} | null>(null);

    const handleLogin = (u: User) => {
        setUser(u);
        if (u.role === 'reitoria') {
            setView('dashboard');
        } else {
            setView('formulario');
        }
    };

    const handleLogout = () => {
        setUser(null);
        setView('login');
        setCart([]);
    };

    const handleSaveToCart = (item: Fragility) => {
        setCart(prev => [...prev, item]);
        setSuccessMessage('A fragilidade foi adicionada à sua lista de envio.');
    };

    const handleRemoveFromCart = (idx: number) => {
        setCart(prev => prev.filter((_, i) => i !== idx));
        if (cart.length <= 1) {
            setIsCartOpen(false);
        }
    };

    const handleSubmitCart = async () => {
        setIsSubmitting(true);
        const success = await submitCart(cart);
        setIsSubmitting(false);
        
        if (success) {
            setCart([]);
            setIsCartOpen(false);
            setSuccessMessage('Itens enviados com sucesso!');
        } else {
            setAlertState({ title: 'Erro', message: 'Falha ao sincronizar dados. Verifique a conexão e tente novamente.' });
        }
    };

    if (view === 'login') {
        return <Login onLogin={handleLogin} />;
    }

    return (
        <div className="bg-slate-50 text-slate-900 min-h-screen flex flex-col relative overflow-x-hidden pt-6">
            <div className="bg-polka"></div>
            
            <main className="w-full max-w-[98%] 2xl:max-w-[1800px] mx-auto p-4 sm:p-6 flex-grow flex-col relative z-10">
                {view === 'formulario' && user?.role === 'coordenador' && (
                    <div className="space-y-8 animate-in w-full text-left">
                        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 bg-white p-4 rounded-2xl bento-shadow border border-slate-100">
                            <div className="flex items-center gap-3 w-full sm:w-auto">
                                <button onClick={handleLogout} className="bg-slate-50 text-slate-500 px-4 py-2.5 rounded-xl text-xs font-bold border border-slate-200 hover:bg-slate-100 transition-all flex items-center gap-2">
                                    <LogOut className="w-4 h-4" /> Sair
                                </button>
                                <span className="text-xs font-black text-uems-blue bg-blue-50 px-3 py-2 rounded-lg border border-blue-100 truncate max-w-[200px] sm:max-w-xs block">
                                    {user.courseName}
                                </span>
                            </div>
                            <div className="flex gap-3 w-full sm:w-auto justify-end">
                                <button onClick={() => setView('dashboard')} className="flex-1 sm:flex-none bg-uems-blue text-white px-5 py-2.5 rounded-xl text-sm font-bold shadow-md hover:bg-uems-dark transition-all flex items-center justify-center gap-2">
                                    <LayoutDashboard className="w-4 h-4 shrink-0" />
                                    <span className="truncate">Acessar Registros</span>
                                </button>
                            </div>
                        </div>

                        <header className="relative min-h-[220px] rounded-[2rem] overflow-hidden flex items-end p-10 bento-shadow">
                            <img src="https://www.uems.br/anexos/imagens/conteudo/uems_imagens_2023-09-22_13-02-19.png" className="absolute inset-0 w-full h-full object-cover" alt="Plano de Ação" />
                            <div className="absolute inset-0 bg-gradient-to-r from-uems-dark/95 via-uems-blue/80 to-transparent"></div>
                            <div className="relative z-10 text-white max-w-2xl text-left">
                                <span className="text-blue-200 font-black tracking-widest uppercase text-[10px] mb-2 block">UEMS • PROE</span>
                                <h1 className="text-5xl font-black tracking-tighter mb-2 leading-none">Plano de Ação</h1>
                                <p className="text-lg text-blue-50 font-medium italic opacity-90">Submeta fragilidades e propostas de ações corretivas para os cursos UEMS.</p>
                            </div>
                        </header>

                        <ActionForm 
                            user={user} 
                            cartLength={cart.length}
                            onSaveToCart={handleSaveToCart} 
                            onReview={() => setIsCartOpen(true)}
                            showAlert={(title, message) => setAlertState({ title, message })}
                        />

                        <div className="text-right pb-8">
                            <button onClick={() => cart.length > 0 && setIsCartOpen(true)} className="bg-slate-100 text-slate-400 text-[10px] font-black px-5 py-2.5 rounded-full uppercase tracking-widest hover:bg-slate-200 transition-colors">
                                {cart.length} itens salvos
                            </button>
                        </div>
                    </div>
                )}

                {view === 'dashboard' && user && (
                    <Dashboard 
                        user={user} 
                        onLogout={handleLogout} 
                        onNewRecord={user.role === 'coordenador' ? () => setView('formulario') : undefined} 
                    />
                )}
            </main>

            <CartModal 
                isOpen={isCartOpen}
                onClose={() => setIsCartOpen(false)}
                cart={cart}
                onRemove={handleRemoveFromCart}
                onSubmit={handleSubmitCart}
                isSubmitting={isSubmitting}
            />

            <SuccessModal 
                isOpen={!!successMessage}
                onClose={() => setSuccessMessage('')}
                message={successMessage}
            />

            <AlertModal
                isOpen={!!alertState}
                onClose={() => setAlertState(null)}
                title={alertState?.title || ''}
                message={alertState?.message || ''}
            />
        </div>
    );
}