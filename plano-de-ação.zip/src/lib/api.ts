import { API_URL } from './constants';
import type { Fragility } from '../types';

export async function fetchDashboardData(): Promise<Fragility[] | null> {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 90000);
        
        const response = await fetch(`${API_URL}?t=${Date.now()}`, {
            signal: controller.signal
        });
        clearTimeout(timeoutId);
        
        const data = await response.json();
        return Array.isArray(data) ? data.reverse() : null;
    } catch (e) {
        console.error("Fetch error:", e);
        return null;
    }
}

export async function submitCart(cart: Fragility[]): Promise<boolean> {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 90000);
        
        const response = await fetch(`${API_URL}?t=${Date.now()}`, {
            method: 'POST',
            mode: 'no-cors',
            headers: { 'Content-Type': 'text/plain' },
            body: JSON.stringify(cart),
            signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        return true;
    } catch(e) {
        console.error("Submit error:", e);
        return false;
    }
}

export async function deleteFragility(ano: string, curso: string, fragilidadeAntiga: string): Promise<boolean> {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 90000);
        
        await fetch(`${API_URL}?t=${Date.now()}`, {
            method: 'POST',
            mode: 'no-cors',
            headers: { 'Content-Type': 'text/plain' },
            body: JSON.stringify({ action: 'delete', ano, curso, fragilidadeAntiga }),
            signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        return true;
    } catch(e) {
        console.error("Delete error:", e);
        return false;
    }
}

export async function updateFragility(
    ano: string, 
    curso: string, 
    fragilidadeAntiga: string, 
    newData: Partial<Fragility>
): Promise<boolean> {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 90000);
        
        await fetch(`${API_URL}?t=${Date.now()}`, {
            method: 'POST',
            mode: 'no-cors',
            headers: { 'Content-Type': 'text/plain' },
            body: JSON.stringify({ 
                action: 'update', 
                ano, 
                curso, 
                fragilidadeAntiga, 
                newData 
            }),
            signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        return true;
    } catch(e) {
        console.error("Update error:", e);
        return false;
    }
}
