export interface Fragility {
    ano: string;
    codigoCurso: string;
    curso: string;
    tipo: string;
    fragilidade: string;
    fonte: string;
    conceito: string;
    acao: string;
    prazo: string;
    responsavel: string;
    recursos: string;
    dataReuniao: string;
    minutaReuniao: string;
}

export interface User {
    role: 'reitoria' | 'coordenador';
    courseId?: string;
    courseName?: string;
}

export type ViewState = 'login' | 'formulario' | 'dashboard';
